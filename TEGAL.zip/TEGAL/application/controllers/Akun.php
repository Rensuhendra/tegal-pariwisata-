<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Akun extends CI_Controller {
	public function index()
	{
		$this->load->view('akun/login');
	}
	public function registrasi()
	{
		$this->load->view('akun/registrasi');
	}
}
