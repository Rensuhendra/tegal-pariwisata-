<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Informasi extends CI_Controller {
    public function index()
	{
		$this->load->view('akun/login');
	}
	public function Makanan()
	{
		$this->load->view('informasi/makanan');
	}
    public function Akomodasi()
	{
		$this->load->view('informasi/akomodasi');
	}
    public function Hotel()
	{
		$this->load->view('informasi/hotel');
	}
}
