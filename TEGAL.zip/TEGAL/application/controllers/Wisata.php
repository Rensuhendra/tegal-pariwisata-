<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Wisata extends CI_Controller {
    public function informasi()
	{
		$this->load->view('wisata/informasi.php');
	}
}
