<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <title>Akomodasi</title>
</head>
<body class="bg-light">
    <nav class="navbar navbar-expand-lg navbar-light bg-white">
        <div class="container-fluid">
            <?= anchor('/', 'Home', array('class'=>'navbar-brand')) ?>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <?= anchor('wisata/informasi', 'Info Wisata', array('class'=>'nav-link')) ?>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle active"  aria-current="page"
                        href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            Lain-lain
                        </a>
                        <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                            <li><?= anchor('informasi/makanan', 'Makanan', array('class'=>'dropdown-item')) ?></li>
                            <li><?= anchor('informasi/akomodasi', 'Akomodasi', array('class'=>'dropdown-item')) ?></li>
                            <li><?= anchor('informasi/hotel', 'Hotel', array('class'=>'dropdown-item')) ?></li>
                        </ul>
                    </li>
                    <li class="nav-item">
                        <?= anchor('akun/registrasi', 'Buat Akun', array('class'=>'nav-link')) ?>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <div class="container-fluid">
        <div class="row">
            <div class="col m-4 p-5 bg-white rounded-3 shadow-sm">
                <h1>Akomodasi</h1>
                <hr>
                <p>Untuk menuju ke pantai-pantai yang berada di Bekasi, dapat ditempuh dengan cara :</p>
                <ul>
                    <li>Naik Kendaraan Pribadi</li>
                    <li>Naik Kendaraan Umum</li>
                </ul>

            </div>
        </div>
    </div>
</body>
</html>