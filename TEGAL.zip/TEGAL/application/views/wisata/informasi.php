<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <title>Informasi Wisata</title>
</head>
<body class="bg-light">
    <nav class="navbar navbar-expand-lg navbar-light bg-white">
        <div class="container-fluid">
            <?= anchor('/', 'Home', array('class'=>'navbar-brand')) ?>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <?= anchor('wisata/informasi', 'Info Wisata', array('class'=>'nav-link active', 'aria-current'=>"page")) ?>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button"
                        data-bs-toggle="dropdown" aria-expanded="false">
                            Lain-lain
                        </a>
                        <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                            <li><?= anchor('informasi/makanan', 'Makanan', array('class'=>'dropdown-item')) ?></li>
                            <li><?= anchor('informasi/akomodasi', 'Akomodasi', array('class'=>'dropdown-item')) ?></li>
                            <li><?= anchor('informasi/hotel', 'Hotel', array('class'=>'dropdown-item')) ?></li>
                        </ul>
                    </li>
                    <li class="nav-item">
                        <?= anchor('akun/registrasi', 'Buat Akun', array('class'=>'nav-link')) ?>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <div class="container-fluid mt-3">
        <div class="row row-cols-3">
            <div class="col">
                <div class="card mb-3">	
                    <img src="<?= base_url('images/air_panas_guci.jpg') ?>" class="card-img-top">
                    <div class="card-body">
                        <h5 class="card-title">Wisata air panas Guci</h5>
                        <p class="card-text">
                            Wisata air panas Guci atau Guci Indah merupakan ikon wisata Tegal. Mengutip situs Perpustakaan Provinsi Jawa Tengah, 
                            terdapat pancuran air panas yang mengalir langsung dari Gunung Slamet. 
                        </p>
                    </div>
                    <div class="card-footer">
                        <small class="text-muted">Last updated 3 mins ago</small>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="card mb-3">	
                    <img src="<?= base_url('images/pantai_alam_indah.jpg') ?>" class="card-img-top">
                    <div class="card-body">
                        <h5 class="card-title">Pantai Alam Indah</h5>
                        <p class="card-text">
                            Berada di pesisir utara, menjadikan Tegal memiliki sejumlah wisata pantai. Salah satu yang paling terkenal adalah Pantai Alam Indah. 
                        </p>
                    </div>
                    <div class="card-footer">
                        <small class="text-muted">Last updated 3 mins ago</small>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="card mb-3">	
                    <img src="<?= base_url('images/pantai_purwahamba_indah.jpg') ?>" class="card-img-top">
                    <div class="card-body">
                        <h5 class="card-title">Pantai Purwahamba Indah</h5>
                        <p class="card-text">
                            Pantai terkenal lainnya di Tegal adalah Pantai Purwahamba Indah atau Pantai Purin. Mengutip situs Visit Jawa Tengah, Pantai Purin 
                            menyediakan fasilitas beragam permainan anak, antara lain waterboom, sepeda air, dan kereta mini. 
                        </p>
                    </div>
                    <div class="card-footer">
                        <small class="text-muted">Last updated 3 mins ago</small>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="card mb-3">	
                    <img src="<?= base_url('images/curug_cantel.jpg') ?>" class="card-img-top">
                    <div class="card-body">
                        <h5 class="card-title">Curug Cantel</h5>
                        <p class="card-text">
                            Curug Cantel menawarkan panorama air terjun eksotis serta asri. Mengutip situs Visit Jawa Tengah, air terjun ini mempunyai ketinggian sekitar 60 meter. 
                        </p>
                    </div>
                    <div class="card-footer">
                        <small class="text-muted">Last updated 3 mins ago</small>
                    </div>
                </div>
            </div>
            <div class="col">
                <div class="card mb-3">	
                    <img src="<?= base_url('images/rita_park.jpg') ?>" class="card-img-top">
                    <div class="card-body">
                        <h5 class="card-title">Rita Park</h5>
                        <p class="card-text">
                            Tegal juga memiliki taman hiburan keluarga yakni Rita Park. Mengutip Tribun Travel (23/3/2022), taman hiburan ini 
                            dilengkapi dengan puluhan wahana yang bisa dinikmati segala kalangan. 
                        </p>
                    </div>
                    <div class="card-footer">
                        <small class="text-muted">Last updated 3 mins ago</small>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>